/*const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
}*/
function check_Alert(){
	var paragraphs=document.getElementsByTagName('tbody');
	var aler=paragraphs[1].getElementsByTagName('tr');
	var notification=aler[0].innerText;
	console.log(notification);
	var notif="https://api.telegram.org/bot1057935331:AAGTaDyHg7uP7E_Vj0RZRLcORo2Y2sq4Kwg/sendMessage?text=".concat(notification);
	const Http = new XMLHttpRequest();
	const url=notif.concat("&chat_id=952828322");
	Http.open("GET", url);
	Http.send();
}
setTimeout(check_Alert,5000);
(function myLoop (i) {          
   let now=new Date().getSeconds();
   let secondsToWait=60-now;
   setTimeout(function () {   
      check_Alert();         //  your code here
      if (--i) myLoop(i);      //  decrement i and call myLoop again if i > 0
   }, 1000*secondsToWait)
})(1000);                        //  pass the number of iterations as an argument
